/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
  function checkForm(form)
            {
                
                
                 
 if( document.getElementById("Doctor").checked===false && document.getElementById("TA").checked===false)
               {     
                   var radio = document.getElementById("radioError");
                    radio.innerHTML = "   Error: you have to select your type";
                    radio.style.color = "red";
                    //form.radio.focus();
                    return false;
                        
                    
                    
                }
                if (form.email.value !== "")
                {
                   
                   if(!validateEmail(form.email.value))
                { 
                    var email = document.getElementById("emailError");
                    email.innerHTML = " Error: InvalidEmail!";
                    email.style.color = "red";
                    form.email.focus();
                    return false;
                }

                }
                
                if (form.pwd1.value === "")
                {
                    var pass = document.getElementById("passError");
                    pass.innerHTML = " Error: Password cannot be blank!";
                    pass.style.color = "red";
                    form.pwd1.focus();
                    return false;

                }
                else if (form.pwd1.value !== form.pwd2.value)
                {
                    var pass = document.getElementById("pass2Error");
                    pass.innerHTML = "Error: Password must match!";
                    pass.style.color = "red";
                    form.pwd2.focus();
                    return false;
                }
                else if (form.pwd1.value !== "" && form.pwd2.value !== "" && form.pwd1.value === form.pwd2.value)
                {
                    var pass = document.getElementById("passError");
                    if (form.pwd1.value.length < 6) {
                        pass.innerHTML = "Error: Password must contain at least six characters!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }
                    if (form.pwd1.value === form.username.value) {
                        pass.innerHTML = "  Error: Password must be different from Username!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }
                   var  re = /[0-9]/;
                    //pass.innerHTML = re.test(form.pwd1.value);
                    if (!re.test(form.pwd1.value)) {
                        pass.innerHTML = "Error: password must contain at least one number (0-9)!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }


                } else {
                    alert("Error: Please check that you've entered and confirmed your password!");
                    form.pwd1.focus();
                    return false;
                }

                alert("You entered a valid password: " + form.pwd1.value);
                return true;
            }
               function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
            function onChange(elem) {
                
                if (elem.name === "email") {
                    document.getElementById("emailError").innerHTML = "";
                }
                
                if (elem.name === "pwd1") {
                    document.getElementById("passError").innerHTML = "";
                }
                if (elem.name === "pwd2") {
                    document.getElementById("pass2Error").innerHTML = "";
                }
            }
 function checkForm2(form)
            {
                 if (form.email.value !== "")
                {
                   
                   if(!validateEmail(form.email.value))
                { 
                    var email = document.getElementById("emailError");
                    email.innerHTML = " Error: InvalidEmail!";
                    email.style.color = "red";
                    form.email.focus();
                    return false;
                }

                }
                
                if (form.pwd1.value === "")
                {
                    var pass = document.getElementById("passError");
                    pass.innerHTML = " Error: Password cannot be blank!";
                    pass.style.color = "red";
                    form.pwd1.focus();
                    return false;

                }
                else if (form.pwd1.value !== form.pwd2.value)
                {
                    var pass = document.getElementById("pass2Error");
                    pass.innerHTML = "Error: Password must match!";
                    pass.style.color = "red";
                    form.pwd2.focus();
                    return false;
                }
                else if (form.pwd1.value !== "" && form.pwd2.value !== "" && form.pwd1.value === form.pwd2.value)
                {
                    var pass = document.getElementById("passError");
                    if (form.pwd1.value.length < 6) {
                        pass.innerHTML = "Error: Password must contain at least six characters!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }
                    if (form.pwd1.value === form.username.value) {
                        pass.innerHTML = "  Error: Password must be different from Username!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }
                   var  re = /[0-9]/;
                    //pass.innerHTML = re.test(form.pwd1.value);
                    if (!re.test(form.pwd1.value)) {
                        pass.innerHTML = "Error: password must contain at least one number (0-9)!";
                        pass.style.color = "red";
                        form.pwd1.focus();
                        return false;
                    }


                } else {
                    alert("Error: Please check that you've entered and confirmed your password!");
                    form.pwd1.focus();
                    return false;
                }

                alert("You entered a valid password: " + form.pwd1.value);
                return true;
            }

       
       