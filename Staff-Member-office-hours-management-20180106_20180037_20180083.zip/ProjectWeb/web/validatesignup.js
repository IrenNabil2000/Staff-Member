function checkForm(form)
            {
                if (form.username.value === "" ) {
                    var userName = document.getElementById("usernameError");
                    userName.innerHTML = "   Error: Username cannot be blank!";
                    //document.getElementById("usernameError").innerHTML="   Error: Username cannot be blank!";
                    userName.style.color = "red";
                    form.username.focus();
                    return false;
                }
               if (form.userID.value=== "" )
                {
                     var ID = document.getElementById("userIDError");
                    ID.innerHTML = "   Error: UserID cannot be blank!";
                    //document.getElementById("usernameError").innerHTML="   Error: Username cannot be blank!";
                   ID.style.color = "red";
                    form.userID.focus();
                    return false;
                }
                
                 else{ 
                     var name=form.userID.value;
                   var xmlhttp = new XMLHttpRequest();
                xmlhttp.open("GET", "user_ajax?name=" + name, true);
                xmlhttp.send();
                //xmlhttp.open("POST", "Login1", true);
                //xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                //xmlhttp.send("name=" + name);
                //alert("xmlhttp.readyState:" + xmlhttp.readyState.toString());
                //alert("xmlhttp.status:" + xmlhttp.status.toString());
                //alert("xmlhttp.statusText: " + xmlhttp.statusText);

                 var userName = document.getElementById("userIDError");
                
                xmlhttp.onreadystatechange = function ()
                {
                    //alert("here in onready function");
                    //alert("xmlhttp.readyState:"+xmlhttp.readyState.toString());
                    //alert("xmlhttp.status:"+xmlhttp.status.toString());
                    if (xmlhttp.readyState === 4 && xmlhttp.status === 200)
                    {
                        //alert("here in if");
                        userName.innerHTML= xmlhttp.responseText.toString();
                        userName.style.color = "red";
                        form.userID.focus();
                         
                          
                        
                       
                    }
                    
                   
                    //  alert("xmlhttp.readyState:"+xmlhttp.readyState.toString());
                    //alert("xmlhttp.status:"+xmlhttp.status.toString());
                }
                if(userName.innerHTML==="UserID already Exists")
                { 
                  return false;
                }
                    
                }
 if(document.getElementById("student").checked===false && document.getElementById("Doctor").checked===false && document.getElementById("TA").checked===false)
               {     
                   var radio = document.getElementById("radioError");
                    radio.innerHTML = "   Error: you have to select your type";
                    radio.style.color = "red";
                    //form.radio.focus();
                    return false;
                        
                    
                    
                }
                if (form.email.value === "")
                {
                   
                    var Email = document.getElementById("emailError");
                    Email.innerHTML = " Error: Email cannot be blank!";
                    Email.style.color = "red";
                    form.email.focus();
                    return false;

                }
                else if(!validateEmail(form.email.value))
                { 
                    var email = document.getElementById("emailError");
                    email.innerHTML = " Error: InvalidEmail!";
                    email.style.color = "red";
                    form.email.focus();
                    return false;
                }
               
                
               var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
var captcha=document.getElementById('CaptchaError');

 if (str1 ===str2){
return true;
}else{
    captcha.innerHtml="Inavlid Captcha";
    alert('Inavlid Captcha');
    form.CaptchaInput.focus();
return false;
}
                

                
            }
            
      
   
            function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

            function onChange(elem) {
                if (elem.name ==="username") {
                    document.getElementById("usernameError").innerHTML = "";
                }
                if (elem.name === "email") {
                    document.getElementById("emailError").innerHTML = "";
                }
              
            }