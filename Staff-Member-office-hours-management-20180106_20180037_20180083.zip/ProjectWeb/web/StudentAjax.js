/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function message(form){
            var name=form.option.value;
                   var xmlhttp = new XMLHttpRequest();
                xmlhttp.open("GET", "FindStaff?course=" + name, true);
                xmlhttp.send();
              

                 var usermessage = document.getElementById("message");
                
                xmlhttp.onreadystatechange = function ()
                {
                 
                    if (xmlhttp.readyState === 4 && xmlhttp.status === 200)
                    {
                        
                        usermessage.innerHTML= xmlhttp.responseText.toString();
                        form.message.focus();
                               
                        
                       
                    }
                    
                   
                };
}