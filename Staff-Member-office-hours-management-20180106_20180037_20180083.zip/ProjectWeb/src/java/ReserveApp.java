/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
@WebServlet(urlPatterns = {"/ReserveApp"})
public class ReserveApp extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            /*select *
             from MyTable
             where CAST(Created as time) between '07:00' and '22:59:59 997'
             */
            Connection con = null;
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";

            con = DriverManager.getConnection(connectionURL);
            Statement Stmt = null;
            ResultSet RS = null;

            Stmt = con.createStatement();
            String t1 = request.getParameter("fromT");
            String t2 = request.getParameter("ToT");

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

            int ID = Integer.parseInt(request.getSession().getAttribute("session_userID").toString().trim());
            java.util.Date util_StartDate = df.parse(request.getParameter("date"));
            java.sql.Date sql_StartDate = new java.sql.Date(util_StartDate.getTime());
            int SID = Integer.parseInt(request.getParameter("member").trim());
            int check = 0;
            PreparedStatement ps = con.prepareStatement("select * from OfficeHours where datee=? and Essn=?");
            ps.setDate(1, sql_StartDate);
            ps.setInt(2, SID);
            RS = ps.executeQuery();

            ResultSet RS2 = null;
            ResultSet RSS = null;

            if (RS.next()) {
                PreparedStatement ps2 = con.prepareStatement("select * from OfficeHours where too >= ? And fromm <= ?");
                ps2.setString(1, t1);
                ps2.setString(2, t2);
                RS2 = ps2.executeQuery();
                if (RS2.next()) {
                    check = 1;
                    PreparedStatement ps3 = con.prepareStatement("insert into reservations values (?,?,?,?)");
                    ps3.setInt(1, RS2.getInt(1));
                    ps3.setInt(2, ID);
                    ps3.setString(3, t1);
                    ps3.setString(4, t2);
                    ps3.execute();
                    PreparedStatement pss = con.prepareStatement("Select * from Staff where Ssn=?");
                    pss.setInt(1, SID);
                    RSS = pss.executeQuery();
                    if (RSS.next()) {
                        String content = "there is meeting reserved from " + t1 + " to " + t2 + " in date" + sql_StartDate;
                        String user=RSS.getString("username");
                         String email=RSS.getString("Email");
                        SendEmail.sendmail(user, " New Meeting", email, content);
                       
                    }

                }

            }
            if (check == 0) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Cannot insert at that time and date');");
                out.println("window.location.href = \"Student.jsp\";");

                out.println("</script>");
                

            } else if (check != 0) {
              
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Reserved Successfully');");
                out.println("window.location.href = \"Student.jsp\";");

                out.println("</script>");
               
            }

        } catch (Exception ex) {
            Logger.getLogger(ReserveApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
