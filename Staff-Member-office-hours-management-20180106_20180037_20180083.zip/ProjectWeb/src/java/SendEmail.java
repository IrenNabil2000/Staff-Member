/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author EGYPT_LAPTOP
 */
import java.security.SecureRandom;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {
     public static void sendmail(String name,String sub,String email,String content) throws Exception{
         System.out.println("prepare to send ");
        Properties p=new Properties();
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.starttls.enable", "true");
         p.put("mail.smtp.host", "smtp.gmail.com");
          p.put("mail.smtp.port", "587");
               String acc="websystem362@gmail.com";
               String pass="webproject1234IS";
               Session s= Session.getInstance(p, new Authenticator(){
                   @Override
                  protected PasswordAuthentication getPasswordAuthentication(){
                       return new PasswordAuthentication(acc,pass);
                   }
        
    });
             Message m= prepareMassege(s, sub,acc,name,email,content); 
             
             Transport.send(m);
             System.out.println("message sent ");
    }
    

    private static Message prepareMassege(Session s , String Sub,String acc,String name,String email,String content) {
       Message me=new MimeMessage(s);
        try {
            me.setFrom(new InternetAddress(acc));
            me.setRecipient(Message.RecipientType.TO, new InternetAddress(email));
            me.setSubject(Sub);
            String password="Dear,"+name+" "+content;
            me.setText(password);
            return me;
        } catch (Exception ex) {
            Logger.getLogger(SendEmail.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
   

}
