/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Egyptlaptop
 */
@WebServlet( urlPatterns = {"/Validatee"})
public class Validatee extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*
    Name:Rawan Abd-El-Aziz Mansour
ID:20180106
Group Number:3IS-S2
***NOTE***** i was have a problem to setup mySQl,my laptop windows installer was terminated 
and there were not solutions for this problem So i used SQL SERVER Management Studio
To access my Database
    */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            
           try {
                String name = request.getParameter("username");
                String pass = request.getParameter("pass");
                Connection con = null;                
                
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                
                String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";
                
                con = DriverManager.getConnection(connectionURL);
                Statement Stmt = null;
                ResultSet RSsf = null;
                 ResultSet RSst = null;
                ResultSet RS1 = null;
                ResultSet RS3 = null;
                Stmt = con.createStatement();
                 
                RSst = Stmt.executeQuery("SELECT * FROM Students WHERE username='" + name + "'AND password='" + pass + "';");
                
                if (!RSst.next()) {
                    RSsf = Stmt.executeQuery("SELECT * FROM Staff WHERE username='" + name + "'AND password='" + pass + "';");
                    if (!RSsf.next()) {
                        
                        out.print("<div style=\"color:red; font-size:33px;\">Your data is invalid</div>");
                        out.println("window.location.href = \"Login.jsp\";");
                             
                    } else {
                        HttpSession session = request.getSession(true);
                        int id =RSsf.getInt("Ssn");
                        String email =RSsf.getString("Email");
                        session.setAttribute("session_userID", id);
                        session.setAttribute("session_username", name);
                        session.setAttribute("session_pass", pass);
                        //too send messsge to staffff
                        LocalDate today=LocalDate.now();
                        int ID = Integer.parseInt(request.getSession().getAttribute("session_userID").toString().trim());
        RS1 = Stmt.executeQuery("Select * from reservations where soltID in(SELECT id FROM OfficeHours WHERE datee='"+today+"'AND Essn="+ID+");");
                        if(RS1.next())
                        { 
                           String from=RS1.getString("froom");
                          
                           String to=RS1.getString("too");
                           

                            
                            String content="you have meeting from "+from+ " to "+to+" Today";
                           
                           
                             SendEmail.sendmail(name,"Todays's meeting",email,content);
                            
                   out.println("<script type=\"text/javascript\">");
           out.println("alert('"+content+"');");
            out.println("window.location.href = \"Staff.jsp\";");
            out.println("</script>");
                   
                 
                        } else{
                             response.sendRedirect("Staff.jsp");
                        }
                    
                    }
                    
                } else {
                    HttpSession session = request.getSession(true);
                     int id =RSst.getInt("Ssn");
                      String email =RSst.getString("Email");
                        session.setAttribute("session_userID", id);
                    session.setAttribute("session_username", name);
                    session.setAttribute("session_pass", pass);
                    //too send messsge to student
                      LocalDate today=LocalDate.now();
                       
        RS1 = Stmt.executeQuery("Select * from reservations where soltID in(SELECT id FROM OfficeHours WHERE datee='"+today+"');");
                        if(RS1.next())
                        { 
                        int student=RS1.getInt("StudentID");
                        if(student==id){
                           String from=RS1.getString("froom");
                          
                           String to=RS1.getString("too");
                        
                            String content="you have meeting from "+from+ " to "+to+" Today";
                           
                             SendEmail.sendmail(name,"Todays's meeting",email,content);
                         out.println("<script type=\"text/javascript\">");
           out.println("alert('"+content+"');");
            out.println("window.location.href = \"Student.jsp\";");
            out.println("</script>");
                             
                   
                        }
                        else
                        {
                             response.sendRedirect("Student.jsp");
                        }
                        }
                       
                   
                    
                }
                
                
            } catch (Exception ex) {
              
                ex.printStackTrace();
            }

        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}