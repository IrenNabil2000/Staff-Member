/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
@WebServlet(urlPatterns = {"/updateStudent"})
public class updateStudent extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            Connection con = null;

            try {
               
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";

                con = DriverManager.getConnection(connectionURL);
                  
             String Dname = request.getParameter("displayname");
            String email = request.getParameter("email");
            
             String password=request.getParameter("pwd1");
           Statement Stmt = null;
                ResultSet RS = null;
                Stmt = con.createStatement();
            int ID = Integer.parseInt(request.getSession().getAttribute("session_userID").toString().trim());
               
             PreparedStatement ps = con.prepareStatement("UPDATE Students SET displayname = ?, password = ? ,Email = ? WHERE  Ssn = ?");

   if(!Dname.equals("")){
      ps.setString(1,Dname);
   }else
   {
       RS = Stmt.executeQuery("SELECT displayname FROM Students WHERE Ssn=" +ID+ ";");
   if(RS.next()){
   Dname=RS.getString("displayname");
     ps.setString(3,email);
   }
         ps.setString(1,Dname);
   }
   
 
    ps.setString(2,password);
 if(!email.equals("")){
  ps.setString(3,email);
 }else{
   RS = Stmt.executeQuery("SELECT Email FROM Students WHERE Ssn=" +ID+ ";");
   if(RS.next()){
   email=RS.getString("Email");
     ps.setString(3,email);
   }
 }
  
    ps.setInt(4, ID);

    
   int rows =ps.executeUpdate();
   if(rows!=0){
     
                  out.println("<script type=\"text/javascript\">");
          out.println("alert('Informations is Updated Successfully');");
            out.println("window.location.href = \"Student.jsp\";");
            out.println("</script>");
                  
   }
              
            } catch (Exception e) {
                
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
