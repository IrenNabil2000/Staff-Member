/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author EGYPT_LAPTOP
 */
@WebServlet(urlPatterns = {"/viewreservations"})
public class viewreservations extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
            Connection con = null;
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";

            con = DriverManager.getConnection(connectionURL);
            Statement Stmt = null;
            ResultSet RS = null;
            ResultSet RS2 = null;
            ResultSet RS3 = null;

            Stmt = con.createStatement();

            int ID = Integer.parseInt(request.getSession().getAttribute("session_userID").toString().trim());

            if (request.getParameter("ViewS") != null) {

                int slotID = Integer.parseInt(request.getParameter("s").trim());
                PreparedStatement ps = con.prepareStatement("Select * From reservations Where  soltID=?");

                ps.setInt(1, slotID);
                RS = ps.executeQuery();
                out.println("<table border=1 align=center >");
                out.println(" <tr>");
                out.println("  <th>Student Name</th>");
                out.println("  <th>Student ID</th>");
                out.println("  <th>From Time</th>");
                out.println("  <th>To Time</th>");
                out.println("  <th>Date</th>");

                out.println(" </tr>");
                out.println(" </thead>");
                out.println(" <tbody>");
                while (RS.next()) {
                    int s = RS.getInt(2);
                    PreparedStatement ps2 = con.prepareStatement("Select * From Students Where Ssn=?");
                    ps2.setInt(1, s);
                    RS2 = ps2.executeQuery();
                    PreparedStatement ps3 = con.prepareStatement("Select * From OfficeHours Where Essn=?");
                    ps3.setInt(1, ID);
                    RS3 = ps3.executeQuery();
                    if (RS2.next() && RS3.next()) {
                        out.println("<tr>");
                        out.println("   <td>" + RS2.getString(3) + "</td>");
                        out.println("   <td>" + s + "</td>");
                        out.println("   <td>" + RS.getString(3) + "</td>");
                        out.println("   <td>" + RS.getString(4) + "</td>");
                        out.println("   <td>" + RS3.getString(5) + "</td>");

                        out.println("  </tr>");
                    }
                }
                out.println(" </tbody>");
                out.println(" </table>");
            } else {
              
             
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

                java.util.Date FromDate = df.parse(request.getParameter("d1"));
                 java.util.Date ToDate = df.parse(request.getParameter("d2"));
                java.sql.Date FromDateSql = new java.sql.Date(FromDate.getTime());
                 java.sql.Date ToDateSql = new java.sql.Date(ToDate.getTime());
                PreparedStatement ps = con.prepareStatement("SELECT * from OfficeHours where(datee BETWEEN ? AND ?); ");

                ps.setDate(1, FromDateSql);
                ps.setDate(2, ToDateSql);
                RS = ps.executeQuery();
                out.println("<table border=1 align=center >");
                out.println(" <tr>");
                out.println("  <th>Student Name</th>");
                out.println("  <th>Student ID</th>");
                out.println("  <th>Slot ID</th>");
                out.println("  <th>From Time</th>");
                out.println("  <th>To Time</th>");
                out.println("  <th>Date</th>");

                out.println(" </tr>");
                out.println(" </thead>");
                out.println(" <tbody>");
                boolean check=false;
                while (RS.next()) {
                    int s = RS.getInt(1);
                   
                    PreparedStatement ps3 = con.prepareStatement("Select * From reservations Where  soltID=?");
                    ps3.setInt(1,s);
                    RS3 = ps3.executeQuery();
                     
                   PreparedStatement ps2 = con.prepareStatement("Select * From Students Where Ssn=?");
                    if (RS3.next()) {
                        int id=RS3.getInt(2);
                         ps2.setInt(1, id);
                    RS2 = ps2.executeQuery();
                    if(RS2.next()){
                        check=true;
                        out.println("<tr>");
                        out.println("   <td>" + RS2.getString(3) + "</td>");
                        out.println("   <td>" + RS3.getInt(2) + "</td>");
                         out.println("   <td>" + RS3.getInt(1) + "</td>");
                        out.println("   <td>" + RS3.getString(3) + "</td>");
                        out.println("   <td>" + RS3.getString(4) + "</td>");
                        out.println("   <td>" + RS.getString(5) + "</td>");

                        out.println("  </tr>");} 
                    }
                }
                if(check==false){

                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('This slot reservations is Not exits');");
                    out.println("</script>");

                }
                out.println(" </tbody>");
                out.println(" </table>");
                
            }

        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
