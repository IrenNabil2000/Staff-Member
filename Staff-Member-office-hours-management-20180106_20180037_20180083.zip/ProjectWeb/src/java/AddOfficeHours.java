/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
@WebServlet(urlPatterns = {"/AddOfficeHours"})
public class AddOfficeHours extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            Connection con=null;
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";

               con=DriverManager.getConnection(connectionURL);
               Statement Stmt=null;
  ResultSet RS=null;
  
   Stmt = con.createStatement();
       
        
              int ID = Integer.parseInt(request.getSession().getAttribute("session_userID").toString().trim());

           String t1=request.getParameter("fromT");
            String t2=request.getParameter("ToT");
            String d=request.getParameter("data");
            String location=request.getParameter("location");
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");  
             
                    java.util.Date util_StartDate = df.parse( request.getParameter("date") );
java.sql.Date sql_StartDate = new java.sql.Date( util_StartDate.getTime() );

            String type=request.getParameter("type");
            
           
            PreparedStatement ps2=con.prepareStatement("Insert into OfficeHours values(?,?,?,?,?,?)");
              ps2.setInt(1, ID);
              ps2.setString(2, t1);
              ps2.setString(3, t2);
              ps2.setDate(4, sql_StartDate);
              ps2.setString(5, type);
               ps2.setString(6, location);
              int f= ps2.executeUpdate();
               if(f!=0){
                 
                   
               
               out.println("<script type=\"text/javascript\">");
          out.println("alert('Office Hours is Inserted Successfully');");
            out.println("window.location.href = \"Manage.jsp\";");
            out.println("</script>");}

               
            }catch(ClassNotFoundException | SQLException | ParseException e)
            {
                out.println(e);
            }
        }
        finally{
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
