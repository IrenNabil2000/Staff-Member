/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author EGYPT_LAPTOP
 */
@WebServlet(urlPatterns = {"/resend"})
public class resend extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          
            String name = request.getParameter("username");
             String Dname = request.getParameter("displayname");
            String email = request.getParameter("email");
            String type=request.getParameter("type");
            String ID = request.getParameter("userID");
               int userID=Integer.parseInt(ID.trim());
            if(type.equalsIgnoreCase("Doctor")){
                type="Doctor";
            }
            else if(type.equalsIgnoreCase("TA"))
            {
                type="TA";
            }
            String randpass="";
       
        // ASCII range - alphanumeric (0-9, a-z, A-Z)
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
 
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();
 
        // each iteration of loop choose a character randomly from the given ASCII range
        // and append it to StringBuilder instance
 
        for (int i = 0; i < 10; i++) {
            int randomIndex = random.nextInt(chars.length());
            sb.append(chars.charAt(randomIndex));
        }
        String subject="Password to be Changed";
 
        randpass="your password is"+sb.toString();
    
             SendEmail.sendmail(name,subject,email,randpass);
               Connection con =null; 
  
    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

    String connectionURL="jdbc:sqlserver://localhost:1433;databaseName=Projectweb;user=roott;password=1234";
                

               con=DriverManager.getConnection(connectionURL);
               Statement Stmt=null;
  ResultSet RS=null;
   Stmt = con.createStatement();
  if(type.equalsIgnoreCase("student"))
   {
      
         PreparedStatement ps=con.prepareStatement("Insert into Students Values(?,?,?,?,?)");
         ps.setInt(1, userID);
            ps.setString(3, name);
             if(Dname !=""){
                 
            ps.setString(2, Dname);}
             else
             {
                 
                 Dname="none";
                  ps.setString(2, Dname);
             }
            ps.setString(4, randpass);
            ps.setString(5, email);
            ps.execute();
            
   }
   else
   {
      
         PreparedStatement ps=con.prepareStatement("Insert into Staff Values(?,?,?,?,?,?)");
          ps.setInt(1, userID);
         ps.setString(2, name);
         if(Dname !=""){
            ps.setString(3, Dname);}
             else
             {
                 Dname="none";
                  ps.setString(3, Dname);
             }
            ps.setString(4, randpass);
            ps.setString(5, email);
            ps.setString(6, type);
            ps.execute();
   }
             
        response.sendRedirect("Login.jsp");     
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(resend.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(resend.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
