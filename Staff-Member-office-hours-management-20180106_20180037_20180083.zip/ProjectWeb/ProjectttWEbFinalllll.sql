create database Projectweb;
Create Table Students(
Ssn int primary key not null,
displayname varchar(255)  Default 'none' ,
username varchar(255) Not NUll,
password varchar(255) Not Null,
Email Varchar(255) Not Null,
);

Insert Into Students (Ssn,username,password,Email)Values('1','rawan','rawan1234','entstud8@gmail.com'); 
Insert Into Students (Ssn,username,password,Email)Values('3','rasha','rasha1234','entstud8@gmail.com');
Insert Into Students (Ssn,username,password,Email)Values('5','heba','heba1234','entstud8@gmail.com');
Insert Into Students (Ssn,username,password,Email)Values('7','mariam','mar1234','entstud8@gmail.com');
Insert Into Students (Ssn,username,password,Email)Values('9','noha','no1234','entstud8@gmail.com');


Create Table Staff(
Ssn int primary key not null,
username varchar(255)  Not NUll,
displayname varchar(255)  Default 'none' ,
password varchar(255) Not Null,
Email Varchar(255) Not Null,
typee varchar(255) Not Null,
);

Insert Into Staff (Ssn,username,password,Email,typee) Values('2','habiba','habiba1234','staffff9@gmail.com','TA');
Insert Into Staff(Ssn,username,password,Email,typee) Values('4','iren','iren1234','staffff9@gmail.com','Doctor');
Insert Into Staff (Ssn,username,password,Email,typee)Values('6','rana','rana1234','staffff9@gmail.com','TA');
Insert Into Staff (Ssn,username,password,Email,typee) Values('8','yassmine','yass1234','staffff9@gmail.com','Doctor');
Insert Into Staff(Ssn,username,password,Email,typee) Values('10','nihal','nihal1234','staffff9@gmail.com','TA');

create table workson(
 Essn int not null foreign key references Staff (Ssn) ,
 cname varchar(255) not null,

 );

 Insert Into workson values(2,'OOP');
Insert Into workson values(4,'OOP');
Insert Into workson values(6,'Web');
Insert Into workson values(8,'software Engineering');
Insert Into workson values(10,'OOP');
Insert Into workson values(10,'Web');

Create Table OfficeHours(
id int identity(1,1) primary key not null,
Essn int foreign key references Staff(Ssn),
fromm varchar(255) not null,
too varchar(255) not null,
datee Date,
typee varchar(20) Not Null,
location varchar(max) not null,
);

Insert Into OfficeHours Values (2,'08:25','09:25','2021-01-11','online','https://us04web.zoom.us/j/4466556539?pwd=VzNTOXBNNllnZmFYbzZmY2ovVCt0QT09');
Insert Into OfficeHours Values (4,'10:25','11:45','2021-01-23','offline','university at the office');
Insert Into OfficeHours Values (6,'16:00','22:25','2021-02-01','online','https://us04web.zoom.us/j/4466556539?pwd=VzNTOXBNNllnZmFYbzZmY2ovVCt0QT09');
Insert Into OfficeHours Values (8,'07:00','09:00','2021-01-15','online','https://us04web.zoom.us/j/4466556539?pwd=VzNTOXBNNllnZmFYbzZmY2ovVCt0QT09');
Insert Into OfficeHours Values (10,'11:00','13:00','2021-01-18','offline','University at the office ');

Create Table reservations(
soltID int  foreign key references OfficeHours(id),
StudentID int foreign key references Students(Ssn),
froom varchar(20) not null,
too varchar(20) not null,
primary key(soltID,StudentID),
);

Insert Into reservations Values (1,1,'08:08','08:38');
Insert Into reservations Values (1,5,'17:00','17:35');
Insert Into reservations Values (3,3,'07:30','08:00');
Insert Into reservations Values (4,1,'08:08','08:38');
Insert Into reservations Values (4,7,'17:00','17:35');
Insert Into reservations Values (5,9,'08:08','08:38');
Insert Into reservations Values (5,3,'17:00','17:35');

create table Messagee(
id int identity(1,1) primary key not null,
too int not null,
froom int not null,
content varchar(max) not null,
reply varchar(max) not null  Default 'none',
);

insert into messagee(too,froom,content) values(1,2,'There is a section today ');
insert into messagee(too,froom,content) values(3,4,'mid term grades is uploaded now ');
insert into messagee(too,froom,content) values(5,6,'If any one have complain please contact me');
insert into messagee(too,froom,content) values(7,8,'Lecture for today is canceled');
insert into messagee(too,froom,content) values(9,10,'Note that discussion sheet is uploaded now reseve the time for you and your team');

insert into messagee(too,froom,content) values(2,9,'What is the time for the lecture today?');
insert into messagee(too,froom,content) values(4,7,'There is something wrong with my Internet connect i cannot attend discussion today ');
insert into messagee(too,froom,content) values(6,5,'there is something wrong with my midterm grade');
insert into messagee(too,froom,content) values(6,3,'i send you a mail with the modification of the assignment');
insert into messagee(too,froom,content) values(8,1,'what is the time for discussing the thirs assdignment');

select * from Messagee;
select * from workson;
Select * from reservations;
select * from Staff;
select * from Students;
Select * from messagee;

